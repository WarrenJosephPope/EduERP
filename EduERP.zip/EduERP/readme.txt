To import the database
1) Create a new database named 'erp' with collation set to 'latin1_swedish_ci.'
2) Select this database and click on the import tab.
3) Choose the erp.sql file present in the folder and click on 'Go.'